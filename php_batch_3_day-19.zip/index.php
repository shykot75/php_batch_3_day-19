<?php
    require_once('vendor/autoload.php');
    use App\classes\Auth;

    $auth = new Auth();
    $auth->login();